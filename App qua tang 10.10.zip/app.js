'use strict';
/* =========================================================
   MỞ QUÁN — Bộ công cụ mở quán đầu tiên (SaLy Academy)
   ---------------------------------------------------------
   CẤU HÌNH GỬI FORM
   Dán địa chỉ nhận dữ liệu (ví dụ webhook n8n) vào SUBMIT_URL.
   - Để trống  → form chỉ hiển thị bản xem trước, không gửi đi.
   - Có địa chỉ → form gửi POST JSON = registrationPayload().
   ========================================================= */
const SUBMIT_URL = '';

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const fmt = (n, d = 0) => new Intl.NumberFormat('vi-VN', { maximumFractionDigits: d }).format(n);
const money = n => fmt(Math.round(n)) + ' đ';
const mil = n => fmt(n, 2) + ' triệu';
const milShort = n => fmt(n, 1) + ' tr';
const pct = n => fmt(n, 1) + '%';
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/* Dữ liệu (mô hình, số liệu mẫu, khóa học) nằm trong data.js */
const STEP_INFO = {
  budget: { label: 'Vốn đầu tư' },
  breakeven: { label: 'Hòa vốn', ownerLabel: 'Lãi lỗ' },
  menu: { label: 'Giá vốn menu' },
  location: { label: 'Mặt bằng' },
  checklist: { label: 'Lộ trình' }
};
const FLOWS = { new: ['budget', 'breakeven', 'menu', 'location', 'checklist'], owner: ['breakeven', 'menu'] };

/* ---------- Trạng thái ---------- */
let mode = 'new', capital = 0, key = 'cart', stepIndex = 0, states = {}, locationIndex = 0, ownerPick = 'takeaway';
let visited = new Set();
let consultationInterest = '', selectedCourse = null;

/* Biểu tượng mô hình (vẽ tay, theo màu SaLy) */
const ICONS = {
  kiosk: '<svg viewBox="0 0 48 48" fill="none" stroke-linejoin="round" stroke-linecap="round"><path d="M7 18 10 8h28l3 10" stroke="#007043" stroke-width="2.6"/><path d="M7 18a4.25 4.25 0 0 0 8.5 0 4.25 4.25 0 0 0 8.5 0 4.25 4.25 0 0 0 8.5 0 4.25 4.25 0 0 0 8.5 0" fill="#F08B36" stroke="#007043" stroke-width="2.6"/><path d="M15.5 18 17 8M24 18V8M32.5 18 31 8" stroke="#007043" stroke-width="2"/><path d="M10 23v17h28V23" stroke="#007043" stroke-width="2.6"/><path d="M10 31h28" stroke="#007043" stroke-width="2.6"/><path d="M21 31l1-5h4l1 5" fill="#FFE9D6" stroke="#B95F14" stroke-width="2"/></svg>',
  cup: '<svg viewBox="0 0 48 48" fill="none" stroke-linejoin="round" stroke-linecap="round"><path d="M28 13 32 4" stroke="#007043" stroke-width="2.6"/><path d="M12 13h24l-1 4H13z" fill="#007043" stroke="#007043" stroke-width="2.6"/><path d="M14 17l2.5 25h15L34 17" fill="#FFE9D6" stroke="#007043" stroke-width="2.6"/><path d="M15.5 27h17" stroke="#F08B36" stroke-width="2.6"/></svg>',
  seated: '<svg viewBox="0 0 48 48" fill="none" stroke-linejoin="round" stroke-linecap="round"><path d="M18 6c-2 2 2 4 0 6M25 6c-2 2 2 4 0 6" stroke="#F08B36" stroke-width="2.4"/><path d="M9 17h24v9a10 10 0 0 1-10 10h-4A10 10 0 0 1 9 26z" fill="#FFE9D6" stroke="#007043" stroke-width="2.6"/><path d="M33 20h3a4 4 0 0 1 0 8h-3" stroke="#007043" stroke-width="2.6"/><path d="M5 41h34" stroke="#007043" stroke-width="2.6"/></svg>',
  store: '<svg viewBox="0 0 48 48" fill="none" stroke-linejoin="round" stroke-linecap="round"><path d="M5 17 8 7h32l3 10" stroke="#007043" stroke-width="2.6"/><path d="M5 17a4.75 4.75 0 0 0 9.5 0 4.75 4.75 0 0 0 9.5 0 4.75 4.75 0 0 0 9.5 0 4.75 4.75 0 0 0 9.5 0" fill="#F08B36" stroke="#007043" stroke-width="2.6"/><path d="M8 22v19h32V22" stroke="#007043" stroke-width="2.6"/><path d="M13 41V29h8v12" fill="#FFE9D6" stroke="#007043" stroke-width="2.4"/><path d="M26 27h9v7h-9z" fill="#FFE9D6" stroke="#007043" stroke-width="2.4"/></svg>'
};
const iconFor = k => ICONS[templates[k].icon] || '';

const route = v => v < ROUTE_LIMITS.takeaway ? 'cart' : v < ROUTE_LIMITS.seated ? 'takeaway' : v < ROUTE_LIMITS.large ? 'seated' : 'large';
const unit = () => 'ly';
const flow = () => FLOWS[mode];
const step = () => flow()[stepIndex];
const stepLabel = s => (mode === 'owner' && STEP_INFO[s].ownerLabel) || STEP_INFO[s].label;

/* Co giãn số mẫu theo vốn khách nhập: chi phí ban đầu + 3 tháng vận hành ≈ 90% vốn, 10% còn lại là quỹ rủi ro */
function scaleFor(t) {
  if (mode !== 'new' || !(capital > 0)) return 1;
  const base = t.costs.reduce((s, x) => s + x[1], 0) + t.fixed.reduce((s, x) => s + x[1], 0) * 3;
  return Math.min(3, Math.max(0.4, capital * 0.9 / base));
}
const half = v => Math.max(0.5, Math.floor(v * 2) / 2);
function fresh(k) {
  const t = templates[k], f = scaleFor(t);
  return { baseCapital: mode === 'new' ? capital : null, costs: t.costs.map(x => [x[0], f === 1 ? x[1] : half(x[1] * f)]), fixed: t.fixed.map(x => [x[0], f === 1 ? x[1] : half(x[1] * f)]), months: 3, risk: 10, days: 30, price: t.price, ingredient: t.ingredient, pack: t.pack, fee: t.fee, promo: t.promo, daily: f === 1 ? t.daily : Math.max(20, Math.round(t.daily * f / 5) * 5), menu: t.menu.map(x => [...x]), checked: [], locations: [0, 1, 2].map(i => ({ name: 'Mặt bằng ' + (i + 1), scores: [3, 3, 3, 3, 3] })) };
}
function current() {
  const s = states[key];
  if (!s || (mode === 'new' && s.baseCapital !== capital) || (mode === 'owner' && s.baseCapital !== null)) states[key] = fresh(key);
  return states[key];
}

function calc(s = current()) {
  const setup = s.costs.reduce((a, x) => a + x[1], 0) * 1e6;
  const fixed = s.fixed.reduce((a, x) => a + x[1], 0) * 1e6;
  const reserve = fixed * s.months;                       // vốn vận hành N tháng đầu
  const risk = capital * 1e6 * (s.risk ?? 10) / 100;      // quỹ dự phòng rủi ro, % tổng vốn
  const margin = s.price - s.ingredient - s.pack - s.price * s.fee / 100 - s.promo;
  return {
    setup, fixed, reserve, risk, need: setup + reserve + risk, gap: capital * 1e6 - setup - reserve - risk, margin,
    breakeven: margin > 0 ? Math.ceil(fixed / margin / s.days) : null,
    profit: s.daily * s.days * margin - fixed
  };
}
const allocActual = vMil => capital > 0 ? vMil / capital * 100 : 0;

/* ---------- Lưu tạm trên máy người dùng ---------- */
const STORE_KEY = 'moquan:v2';
let saveTimer;
function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try { localStorage.setItem(STORE_KEY, JSON.stringify({ mode, capital, key, stepIndex, states, visited: [...visited], savedAt: Date.now() })); } catch { }
  }, 300);
}
function loadSaved() {
  try { const d = JSON.parse(localStorage.getItem(STORE_KEY) || 'null'); if (d && templates[d.key] && FLOWS[d.mode]) return d; } catch { }
  return null;
}

/* =========================================================
   MÀN HÌNH ĐẦU
   ========================================================= */
function setEntryMode(m) {
  const isNew = m === 'new';
  $('#mode-new').classList.toggle('active', isNew); $('#mode-new').setAttribute('aria-selected', String(isNew));
  $('#mode-owner').classList.toggle('active', !isNew); $('#mode-owner').setAttribute('aria-selected', String(!isNew));
  $('#capital-form').hidden = !isNew; $('#owner-form').hidden = isNew;
}
$('#mode-new').addEventListener('click', () => setEntryMode('new'));
$('#mode-owner').addEventListener('click', () => setEntryMode('owner'));

function renderRoutePreview() {
  const v = Number($('#capital').value);
  const ok = $('#capital').value !== '' && v >= 1 && v <= 100000;
  $('#route-preview').innerHTML = ok
    ? `<span class="rp-ico" aria-hidden="true">${iconFor(route(v))}</span><div>Mô hình phù hợp với bạn<strong>${templates[route(v)].name}</strong><small class="rp-note">${templates[route(v)].note}</small></div>`
    : '';
  $('#route-preview').hidden = !ok;
  $$('[data-capital]').forEach(b => b.classList.toggle('selected', Number(b.dataset.capital) === v));
}
function showCapitalError(on) {
  $('#capital-error').hidden = !on;
  $('.big-input').classList.toggle('invalid', on);
  if (on) { const bi = $('.big-input'); bi.classList.remove('shake'); void bi.offsetWidth; bi.classList.add('shake'); }
}
$('#capital').addEventListener('input', () => { showCapitalError(false); renderRoutePreview(); });
$$('[data-capital]').forEach(b => b.addEventListener('click', () => { $('#capital').value = b.dataset.capital; showCapitalError(false); renderRoutePreview(); }));
$('#capital-form').addEventListener('submit', e => {
  e.preventDefault();
  const v = Number($('#capital').value);
  if ($('#capital').value === '' || !(v >= 1 && v <= 100000)) { showCapitalError(true); $('#capital').focus(); return; }
  start({ m: 'new', v });
});

function renderOwnerModels() {
  $('#owner-models').innerHTML = Object.entries(templates).map(([k, t]) =>
    `<button type="button" class="model-opt" role="radio" aria-checked="${k === ownerPick}" data-pick="${k}"><span class="mo-ico" aria-hidden="true">${iconFor(k)}</span><span><strong>${t.name}</strong><small>${esc(t.note)}</small></span></button>`).join('');
}
$('#owner-models').setAttribute('role', 'radiogroup');
$('#owner-models').addEventListener('click', e => { const b = e.target.closest('[data-pick]'); if (!b) return; ownerPick = b.dataset.pick; renderOwnerModels(); });
$('#owner-form').addEventListener('submit', e => { e.preventDefault(); start({ m: 'owner', k: ownerPick }); });

function start({ m, v = 0, k }) {
  mode = m; capital = m === 'new' ? v : 0; key = k || route(v); stepIndex = 0; locationIndex = 0;
  visited = new Set([flow()[0]]);
  $('#consultation').hidden = true; $('#course-section').hidden = true;
  showWorkspace();
  save();
}
function showWorkspace() {
  $('#entry').hidden = true; $('#workspace').hidden = false;
  $('#model-select').value = key;
  $('#back').textContent = mode === 'new' ? '← Đổi số vốn' : '← Đổi mô hình';
  render();
  window.scrollTo({ top: 0, behavior: 'smooth' });
  $('#plan-title').focus({ preventScroll: true });
}
$('#back').addEventListener('click', () => {
  $('#workspace').hidden = true; $('#entry').hidden = false;
  setEntryMode(mode);
  if (mode === 'new') { $('#capital').value = capital || ''; renderRoutePreview(); } else { ownerPick = key; renderOwnerModels(); }
  window.scrollTo({ top: 0, behavior: 'smooth' });
});
$('#model-select').addEventListener('change', e => { key = e.target.value; locationIndex = 0; render(); save(); });

/* =========================================================
   KHU LẬP KẾ HOẠCH
   ========================================================= */
function render() {
  const t = templates[key];
  $('#plan-title').textContent = (mode === 'owner' ? 'Kiểm tra quán ' : '') + t.name;
  $('#plan-eyebrow').textContent = mode === 'owner' ? 'Quán đang kinh doanh' : 'Kế hoạch của bạn · Vốn ' + fmt(capital, 1) + ' triệu';
  renderStepper();
  renderPanel();
  refresh();
}
function renderStepper() {
  const f = flow();
  $('#stepper').innerHTML = f.map((s, i) => `<button type="button" class="step-chip ${i === stepIndex ? 'active' : ''} ${visited.has(s) && i !== stepIndex ? 'done' : ''}" data-step="${i}" ${i === stepIndex ? 'aria-current="step"' : ''}><span class="n">${visited.has(s) && i !== stepIndex ? '✓' : i + 1}</span>${stepLabel(s)}</button>`).join('');
  $('#progress-fill').style.width = ((stepIndex + 1) / f.length * 100) + '%';
  const active = $('#stepper .active'); if (active) active.scrollIntoView({ block: 'nearest', inline: 'center', behavior: 'smooth' });
}
$('#stepper').addEventListener('click', e => { const b = e.target.closest('[data-step]'); if (b) goStep(Number(b.dataset.step)); });
function goStep(i) {
  stepIndex = Math.max(0, Math.min(flow().length - 1, i));
  visited.add(step());
  render(); save();
  const y = $('#stepper').getBoundingClientRect().top + window.scrollY - 70;
  window.scrollTo({ top: y, behavior: 'smooth' });
}
$('#step-prev').addEventListener('click', () => goStep(stepIndex - 1));
$('#step-next').addEventListener('click', () => { if (stepIndex < flow().length - 1) goStep(stepIndex + 1); else showConsultation(); });

/* ---------- Ô nhập số ---------- */
// scale: hệ số đổi giữa giá trị lưu và giá trị hiển thị (VD: lưu đồng, hiển thị nghìn đồng → 1000)
function numInput({ id, path, value, suffix, min = 0, max = 1e6, step = 'any', scale = 1, label }) {
  const shown = +(value / scale).toFixed(3);
  return `<div class="num-wrap"><input id="${id}" type="number" inputmode="decimal" min="${min}" max="${max}" step="${step}" value="${shown}" data-path="${path}" data-scale="${scale}" ${label ? `aria-label="${esc(label)}"` : ''}><span>${suffix}</span></div>`;
}
function setPath(path, v) {
  const s = current(); const parts = path.split('.');
  let o = s; for (let i = 0; i < parts.length - 1; i++) o = o[parts[i]];
  o[parts[parts.length - 1]] = v;
}

/* Nhóm ô nhập thu gọn: mặc định đóng, người dùng bấm để sửa */
const openGroups = new Set();
function group(id, title, sumId, inner, defaultOpen = false, sub = '') {
  const open = openGroups.has(id) || (defaultOpen && !openGroups.has(id + ':closed'));
  return `<details class="group" id="${id}" ${open ? 'open' : ''}><summary><span class="g-title">${title}${sub ? `<small>${sub}</small>` : ''}</span><b id="${sumId}"></b><span class="g-edit">Sửa</span></summary><div class="g-body">${inner}</div></details>`;
}
/* Ô số có nút − / + để không phải gõ */
function plusMinus({ id, path, value, step, min, max, suffix }) {
  return `<div class="pm"><button type="button" class="pm-btn" data-pm="${id}" data-delta="${-step}" aria-label="Giảm ${step}">−</button><label class="pm-val"><input id="${id}" type="number" inputmode="numeric" min="${min}" max="${max}" step="1" value="${value}" data-path="${path}" aria-label="${suffix}"><span>${suffix}</span></label><button type="button" class="pm-btn" data-pm="${id}" data-delta="${step}" aria-label="Tăng ${step}">+</button></div>`;
}

/* ---------- Vẽ từng bước ---------- */
function renderPanel() {
  const s = current(), t = templates[key], u = unit();
  const panel = $('#panel');
  const st = step();

  if (st === 'budget') {
    const a = allocationSuggestions[key];
    panel.innerHTML = `
      <h2>Vốn của bạn có đủ không?</h2>
      <div id="budget-callout"></div>
      ${group('g-setup', 'Chi phí ban đầu', 'setup-sum', `
        ${s.costs.map((x, i) => `
          <div class="cost-row">
            <label for="c-${i}">${esc(x[0])}</label>
            <div class="num">${numInput({ id: 'c-' + i, path: `costs.${i}.1`, value: x[1], suffix: 'tr', max: 100000, step: 0.5 })}</div>
            <div class="note" id="note-${i}">${esc((t.costNotes || [])[i] || '')}</div>
            <div class="hint" id="hint-${i}">Gợi ý ≈ ${milShort(capital * a.costs[i] / 100)}</div>
          </div>`).join('')}
        <div class="inline-actions">
          <button type="button" class="mini-btn" id="apply-suggest">Dùng mức gợi ý</button>
          <button type="button" class="mini-btn" id="reset-template">Đặt lại số mẫu</button>
        </div>`, false, 'Tiền bỏ ra 1 lần trước khi mở')}
      ${group('g-fixed', 'Chi phí tháng', 'fixed-sum', `
        ${s.fixed.map((x, i) => `
          <div class="cost-row">
            <label for="f-${i}">${esc(x[0])}</label>
            <div class="num">${numInput({ id: 'f-' + i, path: `fixed.${i}.1`, value: x[1], suffix: 'tr', max: 100000, step: 0.5 })}</div>
            <div class="note">${esc((t.fixedNotes || [])[i] || '')}</div>
          </div>`).join('')}`, false, 'Tiền trả đều mỗi tháng')}
      <div class="plus-field">
        <span class="pf-label">Vốn vận hành<small id="months-note">Nên đủ 3–6 tháng chi phí</small></span>
        ${plusMinus({ id: 'months', path: 'months', value: s.months, step: 1, min: 0, max: 36, suffix: 'tháng' })}
      </div>
      <div class="plus-field">
        <span class="pf-label">Quỹ rủi ro<small id="risk-note">Nên 10–20% tổng vốn</small></span>
        ${plusMinus({ id: 'risk', path: 'risk', value: s.risk ?? 10, step: 5, min: 0, max: 50, suffix: '% vốn' })}
      </div>
      <details class="explain"><summary>Vốn vận hành và quỹ rủi ro là gì?</summary><p><b>Vốn vận hành:</b> tiền trả thuê, lương, điện nước trong 3–6 tháng đầu khi quán chưa có lãi.<br><b>Quỹ rủi ro:</b> tiền để riêng, thường 10–20% tổng vốn, phòng khi bán chậm hơn dự kiến hoặc có sự cố.</p></details>`;
  }

  if (st === 'breakeven') {
    const owner = mode === 'owner';
    panel.innerHTML = `
      <h2>${owner ? 'Quán đang lãi hay lỗ?' : `Mỗi ngày cần bán mấy ${u}?`}</h2>
      <div id="break-result"></div>
      <div class="plus-field">
        <span class="pf-label">${owner ? `Mỗi ngày quán bán được` : `Bạn nghĩ mỗi ngày bán được`}</span>
        ${plusMinus({ id: 'b-daily', path: 'daily', value: s.daily, step: 5, min: 0, max: 100000, suffix: u })}
      </div>
      ${owner ? group('g-fixed', 'Chi phí tháng', 'fixed-sum', `
        ${s.fixed.map((x, i) => `<div class="cost-row"><label for="f-${i}">${esc(x[0])}</label><div class="num">${numInput({ id: 'f-' + i, path: `fixed.${i}.1`, value: x[1], suffix: 'tr', max: 100000, step: 0.5 })}</div><div class="note">${esc((t.fixedNotes || [])[i] || '')}</div></div>`).join('')}`, true, 'Tiền trả đều mỗi tháng') : ''}
      ${group('g-unit', `Giá &amp; chi phí 1 ${u}`, 'unit-sum', `
        <div class="input-grid">
          <div class="field"><label for="b-price">Giá bán</label>${numInput({ id: 'b-price', path: 'price', value: s.price, suffix: 'nghìn', scale: 1000, step: 0.5 })}</div>
          <div class="field"><label for="b-ing">Nguyên liệu</label>${numInput({ id: 'b-ing', path: 'ingredient', value: s.ingredient, suffix: 'nghìn', scale: 1000, step: 0.5 })}</div>
          <div class="field"><label for="b-pack">Ly, nắp, túi</label>${numInput({ id: 'b-pack', path: 'pack', value: s.pack, suffix: 'nghìn', scale: 1000, step: 0.5 })}</div>
          <div class="field"><label for="b-promo">Khuyến mãi</label>${numInput({ id: 'b-promo', path: 'promo', value: s.promo, suffix: 'nghìn', scale: 1000, step: 0.5 })}</div>
          <div class="field"><label for="b-fee">Phí app giao hàng</label>${numInput({ id: 'b-fee', path: 'fee', value: s.fee, suffix: '%', max: 100, step: 0.5 })}</div>
          <div class="field"><label for="b-days">Ngày bán / tháng</label>${numInput({ id: 'b-days', path: 'days', value: s.days, suffix: 'ngày', min: 1, max: 31, step: 1 })}</div>
        </div>`, owner)}
      <h3>Nếu bán ít hoặc nhiều hơn</h3>
      <div class="scenarios" id="scenarios"></div>
      <details class="explain"><summary>Cách tăng lãi nhanh</summary><div id="levers"></div></details>
      <details class="explain"><summary>Hòa vốn là gì?</summary><p>Là số ${u} cần bán mỗi ngày để đủ trả tiền thuê, lương, điện nước của tháng. Bán nhiều hơn mức này là bắt đầu có lãi. Chưa tính thuế và tiền khấu hao.</p></details>`;
  }

  if (st === 'menu') {
    panel.innerHTML = `
      <h2>Mỗi món còn lại bao nhiêu?</h2>
      <p class="desc">Đơn vị: nghìn đồng (k). Sửa số là thấy ngay.</p>
      <div id="menu-list">${s.menu.map((r, i) => `
        <div class="menu-card">
          <div class="menu-top"><input type="text" maxlength="80" value="${esc(r[0])}" data-menu="${i}" data-col="0" aria-label="Tên món ${i + 1}"><button type="button" class="icon-btn" data-remove="${i}" aria-label="Xóa món ${esc(r[0])}">×</button></div>
          <div class="menu-fields">
            ${['Giá bán', 'Nguyên liệu', 'Bao bì'].map((lb, j) => `<div><label for="m-${i}-${j + 1}">${lb}</label><div class="num-wrap"><input id="m-${i}-${j + 1}" type="number" inputmode="decimal" min="0" max="100000" step="0.5" value="${+(r[j + 1] / 1000).toFixed(3)}" data-menu="${i}" data-col="${j + 1}"><span>k</span></div></div>`).join('')}
          </div>
          <div class="menu-result"><span>Còn lại</span><span><strong id="mm-${i}"></strong><span class="pill" id="mp-${i}"></span></span></div>
        </div>`).join('')}</div>
      <button type="button" class="btn btn-outline btn-block" id="add-menu">+ Thêm món</button>
      <div id="menu-summary"></div>
      <p class="help">Xanh: tốt · Vàng: ổn · Đỏ: nên xem lại công thức hoặc giá bán.</p>`;
  }

  if (st === 'location') {
    const loc = s.locations[locationIndex];
    panel.innerHTML = `
      <h2>Chấm điểm mặt bằng</h2>
      <p class="desc">Bấm điểm cho từng ý. 1 là kém, 5 là rất tốt.</p>
      <div class="loc-tabs">${s.locations.map((x, i) => `<button type="button" data-location="${i}" class="${i === locationIndex ? 'active' : ''}">${esc(x.name || 'Mặt bằng ' + (i + 1))}</button>`).join('')}</div>
      <label class="field"><span class="sr-only">Tên mặt bằng</span><input id="location-name" class="text-input" maxlength="100" value="${esc(loc.name)}" placeholder="Đặt tên, ví dụ: 12 Lê Lợi"></label>
      ${t.criteria.map((c, i) => `
        <div class="rating">
          <div class="rating-top"><span style="color:inherit">${esc(c)}</span><span id="score-${i}">${loc.scores[i]}/5</span></div>
          <div class="rate-btns" role="group" aria-label="${esc(c)}">${[1, 2, 3, 4, 5].map(n => `<button type="button" data-rate="${i}" data-val="${n}" aria-pressed="${loc.scores[i] === n}">${n}</button>`).join('')}</div>
        </div>`).join('')}
      <h3>So sánh 3 nơi</h3>
      <div id="location-summary"></div>
      <p class="help">Nhớ xem kỹ giấy tờ và hợp đồng thuê trước khi đặt cọc.</p>`;
  }

  if (st === 'checklist') {
    panel.innerHTML = `
      <h2>Lộ trình mở ${t.name.toLowerCase()}</h2>
      <p class="desc">Bấm vào việc đã làm xong.</p>
      <div id="check-progress"></div>
      ${t.check.map((x, i) => `<label class="check-row"><input type="checkbox" data-check="${i}" ${s.checked.includes(i) ? 'checked' : ''}><span class="ct">${esc(x)}</span></label>`).join('')}`;
  }
}

/* ---------- Cập nhật kết quả (không vẽ lại ô nhập) ---------- */
function refresh() {
  const s = current(), c = calc(), u = unit(), st = step();
  renderMetrics(c);
  renderSide(c);
  renderStepBar(c);

  if (st === 'budget') {
    const a = allocationSuggestions[key];
    $('#setup-sum').textContent = milShort(c.setup / 1e6);
    $('#fixed-sum').textContent = milShort(c.fixed / 1e6);
    s.costs.forEach((x, i) => {
      const sug = capital * a.costs[i] / 100, el = $('#hint-' + i);
      const over = x[1] - sug > 0.5 && allocActual(x[1]) > a.costs[i] + 3;
      el.innerHTML = `Gợi ý ≈ ${milShort(sug)}${over ? ' · <b class="neg">đang cao hơn</b>' : ''}`;
    });
    const dep = s.costs.findIndex(x => /^Đặt cọc/i.test(x[0])), rent = s.fixed[0] ? s.fixed[0][1] : 0;
    if (dep >= 0) $('#note-' + dep).textContent = rent > 0 ? `Cọc & trả trước ≈ ${fmt(s.costs[dep][1] / rent, 1)} tháng thuê · thường 3–6 tháng` : 'Tiền cọc và trả trước tiền thuê';
    $('#months-note').textContent = `${milShort(c.reserve / 1e6)} · nên đủ 3–6 tháng`;
    $('#risk-note').textContent = `${milShort(c.risk / 1e6)} · nên 10–20% vốn`;
    $('#budget-callout').innerHTML = budgetAdvice(c);
  }

  if (st === 'breakeven') {
    const owner = mode === 'owner';
    if ($('#fixed-sum')) $('#fixed-sum').textContent = milShort(c.fixed / 1e6);
    $('#unit-sum').textContent = `${fmt(s.price / 1000, 1)}k → còn ${fmt(c.margin / 1000, 1)}k`;
    let html;
    if (c.margin <= 0) {
      html = `<div class="big-result warn"><span class="br-label">Chưa thể hòa vốn</span><strong>Đang lỗ mỗi ${u}</strong><p>Giá bán chưa đủ trả nguyên liệu, bao bì và phí. Hãy tăng giá hoặc giảm chi phí.</p></div>`;
    } else {
      const diff = s.daily - c.breakeven;
      html = `<div class="big-result ${diff >= 0 ? 'ok' : 'warn'}"><span class="br-label">Cần bán mỗi ngày</span><strong>${fmt(c.breakeven)} ${u}</strong>
        <p>${diff >= 0 ? `Bán ${fmt(s.daily)} ${u}/ngày → <b>lãi khoảng ${milShort(c.profit / 1e6)}/tháng</b>` : `Bán ${fmt(s.daily)} ${u}/ngày → <b>lỗ khoảng ${milShort(-c.profit / 1e6)}/tháng</b>`}</p></div>`;
    }
    $('#break-result').innerHTML = html;
    $('#scenarios').innerHTML = [['Ít hơn', .8], ['Như dự kiến', 1], ['Nhiều hơn', 1.2]].map(([lb, f], i) => {
      const n = Math.round(s.daily * f), p = n * s.days * c.margin - c.fixed;
      return `<div class="scn ${i === 1 ? 'mid' : ''}"><b>${lb}</b>${fmt(n)} ${u}/ngày<strong class="${p < 0 ? 'neg' : 'pos'}">${p < 0 ? '−' : '+'}${milShort(Math.abs(p) / 1e6)}</strong>mỗi tháng</div>`;
    }).join('');
    $('#levers').innerHTML = leversHtml(s, c);
  }

  if (st === 'menu') {
    let worst = null, sumPct = 0;
    s.menu.forEach((r, i) => {
      const m = r[1] - r[2] - r[3] - r[1] * s.fee / 100 - s.promo;
      const p = r[1] > 0 ? m / r[1] * 100 : 0;
      sumPct += p;
      if (!worst || p < worst.p) worst = { name: r[0], p, m };
      const mm = $('#mm-' + i), mp = $('#mp-' + i);
      mm.textContent = money(m); mm.className = m < 0 ? 'neg' : 'pos';
      const cls = p >= 60 ? 'good' : p >= 45 ? 'mid' : 'bad';
      mp.className = 'pill ' + cls; mp.textContent = pct(p) + ' · ' + (cls === 'good' ? 'Tốt' : cls === 'mid' ? 'Ổn' : 'Thấp');
    });
    $('#menu-summary').innerHTML = s.menu.length ? `<div class="callout ${worst.p < 45 ? 'warn' : 'ok'}"><strong>Trung bình còn ${fmt(sumPct / s.menu.length)}% giá bán</strong>Món lời ít nhất: <b>${esc(worst.name || 'Chưa đặt tên')}</b> (${money(worst.m)})${worst.p < 45 ? '. Nên xem lại công thức hoặc giá bán.' : ''}</div>` : '';
  }

  if (st === 'location') {
    const scored = s.locations.map((l, i) => ({ i, name: l.name || 'Mặt bằng ' + (i + 1), total: l.scores.reduce((a, n) => a + n, 0) }));
    const best = Math.max(...scored.map(x => x.total));
    const tie = scored.every(x => x.total === best);
    $('#location-summary').innerHTML = scored.map(x => `<div class="compare-row ${!tie && x.total === best ? 'best' : ''}"><span>${esc(x.name)}${!tie && x.total === best ? ' ⭐' : ''}</span><b>${x.total}/25</b><div class="compare-bar"><span style="width:${x.total / 25 * 100}%"></span></div></div>`).join('');
    s.locations[locationIndex].scores.forEach((v, i) => { $('#score-' + i).textContent = v + '/5'; });
  }

  if (st === 'checklist') {
    const total = templates[key].check.length;
    $('#check-progress').innerHTML = `<div class="tiny">Đã xong ${s.checked.length}/${total} việc</div><div class="prog"><span style="width:${s.checked.length / total * 100}%"></span></div>`;
  }
}

function budgetAdvice(c) {
  const s = current(), a = allocationSuggestions[key];
  const line = `Cần ${milShort(c.need / 1e6)} · Bạn có ${milShort(capital)}`;
  if (c.gap >= 0) return `<div class="big-result ok"><span class="br-label">Đủ vốn</span><strong>${c.gap < 1e6 ? 'Vừa đủ' : 'Dư ' + milShort(c.gap / 1e6)}</strong><p>${line}</p></div>`;
  const tips = [];
  const over = s.costs.map((x, i) => ({ name: x[0], diff: x[1] - capital * a.costs[i] / 100 })).filter(x => x.diff > 0.5).sort((p, q) => q.diff - p.diff).slice(0, 2);
  over.forEach(x => tips.push(`Giảm <b>${esc(x.name.toLowerCase())}</b> (cao hơn gợi ý ${milShort(x.diff)})`));
  const cash = capital * 1e6 - c.setup - c.risk;
  if (c.fixed > 0 && cash > 0) { const m = Math.floor(cash / c.fixed); if (m >= 3 && m < s.months) tips.push(`Giữ vốn vận hành <b>${m} tháng</b> thay vì ${s.months}`); }
  const fit = route(capital); if (fit !== key) tips.push(`Chọn mô hình <b>${templates[fit].name}</b>`);
  return `<div class="big-result warn"><span class="br-label">Còn thiếu</span><strong>${milShort(-c.gap / 1e6)}</strong><p>${line}</p>${tips.length ? `<ul class="tips">${tips.map(x => `<li>${x}</li>`).join('')}</ul>` : ''}</div>`;
}

function leversHtml(s, c) {
  const u = unit();
  const sim = (ch) => { const t = { ...s, ...ch }; const m = t.price - t.ingredient - t.pack - t.price * t.fee / 100 - t.promo; return { m, be: m > 0 ? Math.ceil(c.fixed / m / t.days) : null, p: t.daily * t.days * m - c.fixed }; };
  const rows = [
    ['Tăng giá 2.000đ', sim({ price: s.price + 2000 })],
    ['Bớt nguyên liệu 1.000đ', sim({ ingredient: Math.max(0, s.ingredient - 1000) })],
    ['Bán thêm 10 ' + u + '/ngày', sim({ daily: s.daily + 10 })]
  ];
  return rows.map(([lb, r]) => {
    const dp = r.p - c.profit;
    const beTxt = r.be === null ? 'chưa hòa vốn' : (c.breakeven !== null && r.be !== c.breakeven ? `hòa vốn còn ${fmt(r.be)} ${u}` : `hòa vốn ${fmt(r.be)} ${u}`);
    return `<div class="compare-row"><span>${lb}<br><span class="tiny">${beTxt}</span></span><b class="${dp >= 0 ? 'pos' : 'neg'}">${dp >= 0 ? '+' : '−'}${milShort(Math.abs(dp) / 1e6)}/tháng</b></div>`;
  }).join('');
}

function renderMetrics(c) {
  const u = unit(), s = current();
  let cards;
  if (mode === 'new') {
    cards = [
      ['featured', 'Vốn của bạn', mil(capital), 'Ngân sách đã nhập'],
      ['', 'Cần tổng', mil(c.need / 1e6), `Gồm vận hành ${s.months} tháng & quỹ rủi ro`],
      [c.gap < 0 ? 'bad' : 'good', c.gap < 0 ? 'Còn thiếu' : 'Còn dư', mil(Math.abs(c.gap) / 1e6), c.gap < 0 ? 'Xem gợi ý cách xử lý' : 'Sau dự phòng'],
      ['', 'Hòa vốn', c.breakeven === null ? 'Chưa thể' : `${fmt(c.breakeven)} ${u}/ngày`, c.breakeven === null ? 'Giá bán chưa đủ bù chi phí' : `${s.days} ngày bán/tháng`]
    ];
  } else {
    cards = [
      ['featured', 'Chi phí cố định', mil(c.fixed / 1e6), 'Mỗi tháng'],
      ['', `Còn lại mỗi ${u}`, money(c.margin), 'Sau nguyên liệu, bao bì, phí'],
      ['', 'Hòa vốn', c.breakeven === null ? 'Chưa thể' : `${fmt(c.breakeven)} ${u}/ngày`, `Đang bán ${fmt(s.daily)} ${u}/ngày`],
      [c.profit < 0 ? 'bad' : 'good', c.profit < 0 ? 'Đang lỗ' : 'Lãi vận hành', mil(Math.abs(c.profit) / 1e6), 'Mỗi tháng, ước tính']
    ];
  }
  $('#metrics').innerHTML = cards.map(([cls, lb, v, sm]) => `<div class="metric ${cls}"><span class="m-label">${lb}</span><strong>${v}</strong><small>${sm}</small></div>`).join('');
}

function renderSide(c) {
  if (mode === 'new') {
    const denom = Math.max(capital * 1e6, c.need, 1);
    const items = [['Chi phí ban đầu', c.setup, '#007043'], ['Vốn vận hành', c.reserve, '#F08B36'], ['Quỹ rủi ro', c.risk, '#B95F14'], ['Chưa dùng', Math.max(c.gap, 0), '#F4CBA5']];
    $('#side-summary').innerHTML = `<span class="kicker">Bức tranh ngân sách</span><h2>${mil(capital)}</h2>
      <div class="alloc-bar">${items.map(x => `<span style="width:${x[1] / denom * 100}%;background:${x[2]}"></span>`).join('')}</div>
      ${items.map(x => `<div class="legend"><span class="sw" style="background:${x[2]}"></span>${x[0]}<b>${mil(x[1] / 1e6)}</b></div>`).join('')}
      <p class="side-insight ${c.gap < 0 ? 'warn' : ''}">${c.gap < 0 ? `Kế hoạch đang vượt vốn ${mil(-c.gap / 1e6)}.` : `Còn dư ${mil(c.gap / 1e6)} sau các khoản dự kiến.`}</p>`;
  } else {
    const s = current(), u = unit();
    $('#side-summary').innerHTML = `<span class="kicker">Tóm tắt quán của bạn</span><h2 class="${c.profit < 0 ? 'neg' : 'pos'}">${c.profit < 0 ? '−' : '+'}${mil(Math.abs(c.profit) / 1e6)}</h2><p class="tiny">Lãi lỗ vận hành ước tính mỗi tháng</p>
      <div class="legend"><span class="sw" style="background:#007043"></span>Đang bán<b>${fmt(s.daily)} ${u}/ngày</b></div>
      <div class="legend"><span class="sw" style="background:#F08B36"></span>Cần để hòa vốn<b>${c.breakeven === null ? '—' : fmt(c.breakeven) + ' ' + u + '/ngày'}</b></div>`;
  }
}

function renderStepBar(c) {
  const f = flow(), st = step(), u = unit(), last = stepIndex === f.length - 1;
  $('#step-prev').disabled = stepIndex === 0;
  $('#step-next').innerHTML = last ? '<span class="btn-ico" aria-hidden="true"></span>Hoàn tất' : `Tiếp<span class="nx-full">: ${stepLabel(f[stepIndex + 1])}</span> →`;
  $('#step-next').setAttribute('aria-label', last ? 'Hoàn tất kế hoạch' : 'Bước tiếp theo: ' + stepLabel(f[stepIndex + 1]));
  let main, cls = '';
  if (st === 'budget') { main = c.gap < 0 ? `Thiếu ${milShort(-c.gap / 1e6)}` : c.gap < 1e6 ? 'Vừa đủ vốn' : `Dư ${milShort(c.gap / 1e6)}`; cls = c.gap < 0 ? 'neg' : 'pos'; }
  else if (st === 'breakeven' || st === 'menu') { main = c.breakeven === null ? 'Chưa hòa vốn' : `Hòa vốn ${fmt(c.breakeven)} ${u}/ngày`; cls = c.breakeven === null || current().daily < c.breakeven ? 'neg' : 'pos'; }
  else if (st === 'location') { const best = current().locations.reduce((a, l) => { const t = l.scores.reduce((x, y) => x + y, 0); return t > a.t ? { t, n: l.name } : a; }, { t: -1, n: '' }); const all = current().locations.every(l => l.scores.reduce((x, y) => x + y, 0) === best.t); main = all ? 'Chưa có nơi nổi bật' : `Cao nhất: ${best.n || 'Mặt bằng'}`; }
  else { const s = current(); main = `Đã xong ${s.checked.length}/${templates[key].check.length} việc`; }
  $('#step-status').innerHTML = `<strong class="${cls}">${esc(main)}</strong>Bước ${stepIndex + 1}/${f.length}${last ? '' : ' · Tiếp: ' + stepLabel(f[stepIndex + 1])}`;
}

/* ---------- Xử lý nhập liệu ---------- */
$('#panel').addEventListener('toggle', e => {
  const d = e.target; if (!d.classList || !d.classList.contains('group')) return;
  if (d.open) { openGroups.add(d.id); openGroups.delete(d.id + ':closed'); } else { openGroups.delete(d.id); openGroups.add(d.id + ':closed'); }
}, true);
$('#panel').addEventListener('input', e => {
  const el = e.target, s = current();
  if (el.dataset.path) {
    if (el.value === '' || !el.checkValidity()) return;
    const v = Number(el.value) * Number(el.dataset.scale || 1);
    if (!Number.isFinite(v)) return;
    setPath(el.dataset.path, v);
  } else if (el.dataset.menu !== undefined) {
    const i = Number(el.dataset.menu), j = Number(el.dataset.col);
    if (j === 0) s.menu[i][0] = el.value;
    else { if (el.value === '' || !el.checkValidity()) return; s.menu[i][j] = Number(el.value) * 1000; }
  } else if (el.id === 'location-name') {
    s.locations[locationIndex].name = el.value;
    const tab = $(`[data-location="${locationIndex}"]`); if (tab) tab.textContent = el.value || 'Mặt bằng ' + (locationIndex + 1);
  } else if (el.dataset.check !== undefined) {
    const i = Number(el.dataset.check);
    s.checked = el.checked ? [...new Set([...s.checked, i])] : s.checked.filter(x => x !== i);
  } else return;
  refresh(); save();
});
$('#panel').addEventListener('click', e => {
  const b = e.target.closest('button'); if (!b) return;
  const s = current();
  if (b.id === 'add-menu') { s.menu.push(['Món mới', 30000, 10000, 2000]); renderPanel(); refresh(); save(); const ins = $$('#menu-list input[data-col="0"]'); ins[ins.length - 1]?.select(); }
  else if (b.dataset.remove !== undefined) { s.menu.splice(Number(b.dataset.remove), 1); renderPanel(); refresh(); save(); }
  else if (b.dataset.location !== undefined) { locationIndex = Number(b.dataset.location); renderPanel(); refresh(); }
  else if (b.dataset.rate !== undefined) { s.locations[locationIndex].scores[Number(b.dataset.rate)] = Number(b.dataset.val); $$(`[data-rate="${b.dataset.rate}"]`).forEach(x => x.setAttribute('aria-pressed', String(x === b))); refresh(); save(); }
  else if (b.id === 'apply-suggest') { const a = allocationSuggestions[key]; s.costs.forEach((x, i) => { x[1] = Math.round(capital * a.costs[i] / 100 * 2) / 2; }); renderPanel(); refresh(); save(); toast('Đã điền mức gợi ý theo số vốn của bạn.'); }
  else if (b.dataset.pm) {
    const inp = $('#' + b.dataset.pm), v = Math.min(Number(inp.max), Math.max(Number(inp.min), Number(inp.value || 0) + Number(b.dataset.delta)));
    inp.value = v; setPath(inp.dataset.path, v); refresh(); save();
  }
  else if (b.id === 'reset-template') { states[key] = fresh(key); renderPanel(); refresh(); save(); toast('Đã đặt lại số liệu mẫu.'); }
});

/* =========================================================
   KẾ HOẠCH DẠNG CHỮ (tải về & gửi kèm)
   ========================================================= */
function planText() {
  const s = current(), c = calc(), t = templates[key], u = unit(), a = allocationSuggestions[key];
  const L = [];
  L.push('MỞ QUÁN — KẾ HOẠCH CỦA BẠN (SaLy Academy)', (mode === 'owner' ? 'Quán đang kinh doanh · ' : 'Chuẩn bị mở quán · ') + t.name, 'Số liệu do bạn nhập hoặc giữ từ mẫu tham khảo của SaLy Academy.', '');
  if (mode === 'new') {
    L.push('Vốn: ' + mil(capital), '', 'CHI PHÍ BAN ĐẦU');
    s.costs.forEach((x, i) => L.push(`- ${x[0]}: ${mil(x[1])} (${pct(allocActual(x[1]))} vốn; gợi ý ${pct(a.costs[i])} ≈ ${mil(capital * a.costs[i] / 100)})`));
    L.push('Tổng chi phí ban đầu: ' + money(c.setup), '');
  }
  L.push('CHI PHÍ CỐ ĐỊNH / THÁNG'); s.fixed.forEach(x => L.push(`- ${x[0]}: ${mil(x[1])}`));
  if (mode === 'new') L.push(`Vốn vận hành ${s.months} tháng: ${money(c.reserve)}`, `Quỹ rủi ro ${s.risk ?? 10}% vốn: ${money(c.risk)}`, 'Tổng vốn cần: ' + money(c.need), (c.gap < 0 ? 'Còn thiếu: ' : 'Còn dư: ') + money(Math.abs(c.gap)));
  L.push('', 'HÒA VỐN', `Giá bán TB: ${money(s.price)} · Nguyên liệu: ${money(s.ingredient)} · Bao bì: ${money(s.pack)}`, `Phí app: ${s.fee}% · Khuyến mãi/QC: ${money(s.promo)}/${u} · ${s.days} ngày/tháng`, `Còn lại mỗi ${u}: ${money(c.margin)}`, `Số ${u}/ngày ${mode === 'owner' ? 'đang bán' : 'dự kiến'}: ${s.daily}`, 'Hòa vốn: ' + (c.breakeven === null ? 'chưa có điểm hòa vốn' : `${c.breakeven} ${u}/ngày`), `Lãi vận hành ước tính: ${money(c.profit)}/tháng`, 'Chưa tính thuế, khấu hao và lãi vay.');
  L.push('', 'MENU — TÊN / GIÁ BÁN / NGUYÊN LIỆU / BAO BÌ'); s.menu.forEach(r => L.push('- ' + r.map((v, i) => i ? money(v) : v).join(' / ')));
  if (mode === 'new') {
    L.push('', 'MẶT BẰNG — THANG ĐIỂM 1–5');
    s.locations.forEach(l => { L.push(`${l.name} (${l.scores.reduce((a, n) => a + n, 0)}/25)`); t.criteria.forEach((q, i) => L.push(`  ${q}: ${l.scores[i]}/5`)); });
    L.push('', 'LỘ TRÌNH'); t.check.forEach((x, i) => L.push((s.checked.includes(i) ? '[x] ' : '[ ] ') + x));
  }
  return L.join('\n');
}
function downloadPlan() {
  const blob = new Blob(['﻿' + planText()], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob), a = document.createElement('a');
  a.href = url; a.download = 'ke-hoach-mo-quan-' + key + '.txt'; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  // Sao chép thêm vào bộ nhớ tạm: phòng khi trình duyệt chặn tải file (ví dụ trong ứng dụng nhắn tin)
  const done = () => toast('Đã tải kế hoạch và sao chép nội dung để bạn dán vào Zalo hoặc ghi chú.');
  try { navigator.clipboard.writeText(planText()).then(done, () => toast('Đã tải kế hoạch về máy.')); } catch { toast('Đã tải kế hoạch về máy.'); }
}
$('#download').addEventListener('click', downloadPlan);
$('#download-2').addEventListener('click', downloadPlan);

/* =========================================================
   TƯ VẤN, KHÓA HỌC & FORM ĐĂNG KÝ
   ========================================================= */
function contextText() { return templates[key].name + (mode === 'new' ? ' · Vốn ' + mil(capital) : ' · Quán đang kinh doanh'); }
function courseKeys() {
  const first = COURSE_BY_MODEL[key];
  return [first, ...Object.values(COURSE_BY_MODEL).filter(k => k !== first)];
}
function renderCourses() {
  $('#course-grid').innerHTML = courseKeys().map((k, i) => {
    const c = COURSES[k];
    return `<article class="course-card ${i === 0 ? 'rec' : ''}"><span class="course-tag">${i === 0 ? 'Phù hợp với bạn' : c.tag}</span>${i === 0 ? `<span class="tiny">${c.tag}</span>` : ''}<h3>${esc(c.title)}</h3><p>${esc(c.subtitle)}</p><ul>${c.topics.map(x => '<li>' + esc(x) + '</li>').join('')}</ul><button type="button" class="btn ${i === 0 ? 'btn-primary' : 'btn-outline'} btn-block" data-course="${k}">Đăng ký tìm hiểu</button></article>`;
  }).join('');
}
function showConsultation() {
  visited.add(step()); renderStepper(); save();
  $('#consultation').hidden = false;
  $('#consultation-context').textContent = contextText();
  renderCourses();
  $('#consultation').scrollIntoView({ behavior: 'smooth', block: 'start' });
  $('#consultation-title').focus({ preventScroll: true });
}
$('#finish-plan').addEventListener('click', showConsultation);
$('#show-courses').addEventListener('click', () => { $('#course-section').hidden = false; renderCourses(); $('#course-section').scrollIntoView({ behavior: 'smooth', block: 'start' }); });

function planSnapshot() {
  return { model: key, model_name: templates[key].name, visitor_type: mode === 'new' ? 'chuan_bi_mo' : 'dang_kinh_doanh', capital_vnd: capital * 1e6, inputs: JSON.parse(JSON.stringify(current())), suggested_allocation: JSON.parse(JSON.stringify(allocationSuggestions[key])), results: calc(), text: planText() };
}
const TIMELINE = {
  new: ['Bạn dự kiến mở quán khi nào?', ['Đang tìm hiểu', 'Trong 1 tháng tới', 'Trong 1–3 tháng tới', 'Trong 3–6 tháng tới', 'Sau 6 tháng']],
  owner: ['Quán bạn đã hoạt động bao lâu?', ['Dưới 3 tháng', '3–12 tháng', '1–3 năm', 'Trên 3 năm']]
};
function openRegistration(interest, course = null) {
  consultationInterest = interest; selectedCourse = course;
  $('#registration-interest').textContent = interest;
  const [lb, opts] = TIMELINE[mode];
  $('#lead-timeline-label').textContent = lb;
  $('#lead-timeline').innerHTML = opts.map(o => `<option>${o}</option>`).join('');
  $('#attachment-summary').textContent = contextText();
  $('#attachment-content').textContent = planText();
  $('#registration-form').hidden = false; $('#registration-preview').hidden = true;
  $('#preview-registration').lastChild.textContent = SUBMIT_URL ? 'Gửi đăng ký' : 'Xem trước đăng ký';
  $$('.demo-note').forEach(n => { n.hidden = !!SUBMIT_URL; });
  $('#registration-dialog').showModal();
  setTimeout(() => $('#lead-name').focus(), 60);
}
$('#consult-direct').addEventListener('click', () => openRegistration('Tư vấn kế hoạch ' + templates[key].name.toLowerCase()));
$('#course-grid').addEventListener('click', e => { const b = e.target.closest('[data-course]'); if (b) openRegistration('Tìm hiểu khóa học: ' + COURSES[b.dataset.course].title, b.dataset.course); });
$('#close-registration').addEventListener('click', () => $('#registration-dialog').close());
$('#registration-dialog').addEventListener('click', e => { if (e.target === e.currentTarget) e.currentTarget.close(); });
['#lead-phone', '#lead-name'].forEach(id => $(id).addEventListener('input', () => $(id).setCustomValidity('')));

function registrationPayload() {
  return {
    schema_version: 2, created_at: new Date().toISOString(),
    contact: { name: $('#lead-name').value.trim(), phone: $('#lead-phone').value.trim(), email: $('#lead-email').value.trim(), timeline_question: $('#lead-timeline-label').textContent, timeline: $('#lead-timeline').value, message: $('#lead-message').value.trim() },
    interest: consultationInterest, course_model: selectedCourse, consent: $('#lead-consent').checked, source: location.href, plan: planSnapshot()
  };
}
$('#registration-form').addEventListener('submit', async e => {
  e.preventDefault();
  if (!$('#lead-name').value.trim()) { $('#lead-name').setCustomValidity('Vui lòng nhập họ và tên.'); $('#lead-name').reportValidity(); return; }
  const digits = $('#lead-phone').value.replace(/\D/g, '');
  if (digits.length < 9 || digits.length > 15) { $('#lead-phone').setCustomValidity('Vui lòng nhập số điện thoại có 9–15 chữ số.'); $('#lead-phone').reportValidity(); return; }
  if (!e.target.reportValidity()) return;
  const payload = registrationPayload(), c = payload.contact;

  if (SUBMIT_URL) {
    const btn = $('#preview-registration'); btn.disabled = true; btn.lastChild.textContent = 'Đang gửi…';
    try {
      const r = await fetch(SUBMIT_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      if (!r.ok) throw new Error(r.status);
      $('#lead-review').innerHTML = `<div class="success"><div class="tick">✓</div><h3>Đã gửi đăng ký!</h3><p>Cảm ơn ${esc(c.name)}. Đội ngũ tư vấn SaLy Academy sẽ liên hệ qua số ${esc(c.phone)} sớm nhất.</p></div>`;
      $('#edit-registration').hidden = true;
      $('#registration-form').hidden = true; $('#registration-preview').hidden = false;
    } catch { toast('Chưa gửi được. Vui lòng kiểm tra mạng và thử lại.'); }
    finally { btn.disabled = false; btn.lastChild.textContent = 'Gửi đăng ký'; }
    return;
  }

  $('#lead-review').innerHTML = `<dl><dt>Họ và tên</dt><dd>${esc(c.name)}</dd><dt>Điện thoại / Zalo</dt><dd>${esc(c.phone)}</dd>${c.email ? `<dt>Email</dt><dd>${esc(c.email)}</dd>` : ''}<dt>Nhu cầu</dt><dd>${esc(payload.interest)}</dd><dt>${esc(c.timeline_question)}</dt><dd>${esc(c.timeline)}</dd>${c.message ? `<dt>Lời nhắn</dt><dd>${esc(c.message)}</dd>` : ''}<dt>Kế hoạch đính kèm</dt><dd>${esc(contextText())}</dd></dl><details><summary>Xem toàn bộ kế hoạch gửi kèm</summary><pre>${esc(payload.plan.text)}</pre></details>`;
  $('#edit-registration').hidden = false;
  $('#registration-form').hidden = true; $('#registration-preview').hidden = false;
  $('#registration-dialog').scrollTop = 0;
});
$('#edit-registration').addEventListener('click', () => { $('#registration-preview').hidden = true; $('#registration-form').hidden = false; $('#lead-name').focus(); });

/* ---------- Thông báo nhỏ ---------- */
let toastTimer;
function toast(msg) { $('#toast').textContent = msg; clearTimeout(toastTimer); toastTimer = setTimeout(() => { $('#toast').textContent = ''; }, 3500); }

/* ---------- Khởi động ---------- */
renderRoutePreview();
renderOwnerModels();
(function initResume() {
  const d = loadSaved(); if (!d) return;
  // Giữ lại số liệu đã nhập, và điền sẵn số vốn cũ để bấm "Xem kế hoạch" là làm tiếp được
  states = d.states || {};
  if (d.mode === 'new' && d.capital) { $('#capital').value = d.capital; renderRoutePreview(); }
  if (d.mode === 'owner') { ownerPick = d.key; renderOwnerModels(); setEntryMode('owner'); }
  $('#resume').hidden = false;
  $('#resume-text').textContent = templates[d.key].name + (d.mode === 'new' && d.capital ? ' · Vốn ' + mil(d.capital) : ' · Quán đang kinh doanh');
  $('#resume-btn').addEventListener('click', () => {
    mode = d.mode; capital = d.capital || 0; key = d.key; states = d.states || {};
    stepIndex = Math.min(d.stepIndex || 0, flow().length - 1); visited = new Set(d.visited || [step()]);
    showWorkspace();
  });
})();

/* ---------- Công cụ cho trợ lý AI trên trình duyệt (nếu có) ---------- */
if (document.modelContext?.registerTool) {
  const lifecycle = new AbortController();
  try {
    Promise.resolve(document.modelContext.registerTool({
      name: 'start_investment_plan', title: 'Mở kế hoạch theo số vốn',
      description: 'Nhập vốn tính bằng triệu đồng và mở mẫu kế hoạch tương ứng. Không gửi hay lưu thông tin ra ngoài.',
      inputSchema: { type: 'object', properties: { capital_million: { type: 'number', minimum: 1, maximum: 100000 } }, required: ['capital_million'], additionalProperties: false },
      annotations: { readOnlyHint: false, untrustedContentHint: false },
      execute(input) {
        if (typeof input !== 'object' || input === null || Object.keys(input).some(k => k !== 'capital_million') || typeof input.capital_million !== 'number' || !(input.capital_million >= 1 && input.capital_million <= 100000)) throw Error('Cần capital_million là số từ 1 đến 100000.');
        start({ m: 'new', v: input.capital_million });
        const c = calc(); return { model: key, capital_million: capital, total_required_vnd: c.need, breakeven_daily: c.breakeven };
      }
    }, { signal: lifecycle.signal })).catch(() => { });
    window.addEventListener('pagehide', () => lifecycle.abort(), { once: true });
  } catch { }
}
