/* =========================================================
   DỮ LIỆU CỦA APP MỞ QUÁN — Phòng Đào tạo sửa số liệu tại đây
   ---------------------------------------------------------
   CHUẨN MÔ HÌNH & KHÓA HỌC (theo bảng Anh Sang chốt):
   | Vốn dự kiến   | Mô hình phù hợp                         | Khóa học điều hướng                                 |
   | 50–70 triệu   | Take away / Xe trà (chỉ bán mang đi)    | Khóa học pha chế kinh doanh Xe Trà                  |
   | 100–200 triệu | Take away kết hợp thêm Trà và Cafe      | Khóa học pha chế kinh doanh Coffee & Tea – Take Away |
   | Từ 300 triệu  | Quán ngồi lại                           | Khóa học pha chế kinh doanh Coffee & Tea – Ngồi Lại |
   | Từ 500 triệu  | Quán ngồi lại có quy mô lớn             | Khóa học pha chế kinh doanh (Tổng hợp)              |
   Ví dụ thực tế (chỉ dùng nội bộ, không hiện trên app):
   - Take away Trà & Cafe: Lục THL, Lục LQD, Ngô Gia
   - Quán ngồi lại: Lục Trường Sa, Loco coffee & tea

   Chia mô hình theo vốn nhập (các khoảng trống trong bảng gộp vào mô hình nhỏ hơn):
   dưới 100 triệu → Take away (bán mang đi) · 100 đến dưới 300 → Take away · 300 đến dưới 500 → Ngồi lại · từ 500 → Ngồi lại quy mô lớn

   SỐ LIỆU CHI PHÍ / GIÁ VỐN: chưa có trong kho tri thức Học viện; Anh Sang tạm xác nhận
   (01/10/2026). Mô hình "Ngồi lại quy mô lớn" và các món mới (Trà sữa, Nước ép) là số
   ước tính ban đầu, CHỜ PHÒNG ĐÀO TẠO XÁC NHẬN.

   costNotes / fixedNotes: chú thích nhỏ dưới từng khoản (để trống '' nếu không cần).
   Tham khảo cấu trúc vốn (Sapo, Tendoo, H3 Group): chi phí ban đầu + vốn vận hành 3–6 tháng
   + quỹ rủi ro 10–20% tổng vốn. App mặc định quỹ rủi ro 10% (s.risk).
   Số mẫu gốc dưới đây là cho 1 quán điển hình. Khi khách nhập vốn, app tự nhân tỷ lệ
   (chi phí ban đầu + chi phí tháng) để kế hoạch ban đầu vừa đủ vốn (xem scaleFor trong app.js).
   Đặt cọc mặt bằng (mặc định 3 tháng tiền thuê): app tự ghi "≈ N tháng tiền thuê" = tiền cọc ÷ tiền thuê tháng.

   Đơn vị: chi phí ban đầu & cố định = triệu đồng;
           giá bán, nguyên liệu, bao bì, khuyến mãi = đồng;
           fee = % giá bán; daily = số ly mỗi ngày.
   ========================================================= */
const ROUTE_LIMITS = { takeaway: 100, seated: 300, large: 500 }; // triệu đồng

const templates = {
  cart: {
    name: 'Take away (bán mang đi)', icon: 'kiosk', range: '50–70 triệu',
    note: 'Quầy nhỏ, vốn tinh gọn, dễ bắt đầu. Chỉ bán mang đi.',
    costNotes: ['Quầy hoặc xe đẩy, mái che, kệ', 'Thùng đá, bình ủ trà, máy dập nắp, máy tính tiền (POS)', 'Bảng hiệu, bảng menu, đồng phục', 'Trà, đường, trái cây, ly, ống hút cho những ngày đầu', 'Cọc chỗ bán, điện nước tạm', 'Giấy phép kinh doanh, vệ sinh an toàn thực phẩm, phát sinh'],
    fixedNotes: ['Tiền thuê chỗ bán mỗi tháng', 'Lương người bán, tính cả công của bạn', 'Điện, nước, gas, chi phí lặt vặt'],
    costs: [['Quầy / xe bán hàng', 16], ['Dụng cụ & thiết bị', 9], ['Nhận diện & bảng hiệu', 2], ['Nguyên liệu, bao bì đầu kỳ', 4], ['Chuẩn bị điểm bán & đặt cọc', 4], ['Chi phí khác trước mở bán', 2]],
    fixed: [['Chi phí điểm bán', 2], ['Nhân sự, gồm công của chủ', 6], ['Điện, nước & chi phí khác', 1]],
    price: 25000, ingredient: 7000, pack: 2000, fee: 0, promo: 0, daily: 50,
    menu: [['Trà đào', 25000, 7000, 2000], ['Trà tắc', 20000, 5000, 2000], ['Trà vải', 25000, 7500, 2000]],
    criteria: ['Khách mục tiêu vào giờ bán', 'Dễ nhìn thấy & dừng mua', 'Được phép bán tại điểm này', 'Điện, nước & chỗ bảo quản', 'Chi phí điểm bán phù hợp'],
    check: ['Xác định khách và khung giờ bán', 'Khảo sát, xác minh điều kiện điểm bán', 'Chốt menu và thử công thức', 'Lấy báo giá quầy, dụng cụ, nguyên liệu', 'Tập quy trình pha chế và thu tiền', 'Bán thử, ghi nhận chi phí thực tế']
  },
  takeaway: {
    name: 'Take away Trà & Cafe', icon: 'cup', range: '100–200 triệu',
    note: 'Bán mang đi, menu rộng hơn: trà trái cây, trà sữa và cà phê.',
    costNotes: ['', 'Sửa mặt bằng, làm quầy, đi điện nước', 'Máy pha cà phê, máy xay, tủ mát, máy dập nắp, máy tính tiền (POS)', 'Bảng hiệu, menu, logo', 'Nguyên liệu, ly, nắp, túi cho những ngày đầu', 'Giấy phép kinh doanh, vệ sinh an toàn thực phẩm, quà khai trương, quảng cáo'],
    fixedNotes: ['Tiền thuê mặt bằng mỗi tháng', 'Lương nhân viên, tính cả công của bạn', 'Điện, nước, internet, chi phí lặt vặt'],
    costs: [['Đặt cọc mặt bằng', 27], ['Sửa chữa & quầy pha chế', 30], ['Thiết bị & dụng cụ', 35], ['Biển hiệu & nhận diện', 7], ['Nguyên liệu, bao bì đầu kỳ', 8], ['Pháp lý & khai trương', 5]],
    fixed: [['Tiền thuê', 9], ['Nhân sự, gồm công của chủ', 12], ['Điện, nước & chi phí khác', 4]],
    price: 32000, ingredient: 9500, pack: 2500, fee: 0, promo: 1000, daily: 85,
    menu: [['Cafe sữa', 28000, 7500, 2500], ['Trà trái cây', 32000, 9000, 2500], ['Trà sữa', 30000, 9000, 2500]],
    criteria: ['Khách mục tiêu quanh khu vực', 'Mặt tiền & dễ nhìn thấy', 'Chỗ dừng xe, lấy hàng', 'Điện nước & bố trí quầy', 'Chi phí thuê phù hợp'],
    check: ['Khảo sát khách quanh mặt bằng', 'Kiểm tra điều kiện và hợp đồng thuê', 'Chốt menu, thiết bị và nhà cung cấp', 'Hoàn thiện quầy và nhận diện', 'Tuyển người, tập pha chế và nhận đơn', 'Chạy thử trước khai trương']
  },
  seated: {
    name: 'Quán ngồi lại', icon: 'seated', range: 'Từ 300 triệu',
    note: 'Có không gian ngồi lại, menu đa dạng hơn, thường thêm nước ép.',
    costNotes: ['', 'Thiết kế, sửa mặt bằng, điện nước, quầy bar', 'Bàn ghế, đèn, cây xanh, trang trí', 'Máy pha cà phê, máy xay, máy ép, tủ mát, tủ đông, máy tính tiền (POS)', 'Máy lạnh, đèn, âm thanh, wifi, camera', 'Nguyên liệu những ngày đầu, giấy phép kinh doanh, vệ sinh an toàn thực phẩm, khai trương'],
    fixedNotes: ['Tiền thuê mặt bằng mỗi tháng', 'Lương nhân viên, tính cả công của bạn', 'Điện, nước, internet, chi phí lặt vặt'],
    costs: [['Đặt cọc mặt bằng', 54], ['Thiết kế, thi công & sửa chữa', 85], ['Bàn ghế, nội thất & trang trí', 45], ['Thiết bị pha chế & bảo quản', 50], ['Điều hòa, ánh sáng & tiện ích', 25], ['Nguyên liệu, pháp lý & khai trương', 14]],
    fixed: [['Tiền thuê', 18], ['Nhân sự, gồm công của chủ', 28], ['Điện, nước & chi phí khác', 9]],
    price: 42000, ingredient: 13000, pack: 1000, fee: 0, promo: 1000, daily: 120,
    menu: [['Cafe sữa', 35000, 8500, 1000], ['Trà trái cây', 45000, 14000, 1000], ['Matcha latte', 49000, 17000, 1000], ['Nước ép cam', 45000, 16000, 1000]],
    criteria: ['Khách mục tiêu & dễ tiếp cận', 'Chỗ đỗ xe và lối vào', 'Diện tích, bố trí chỗ ngồi', 'Điện nước, tiện ích, hiện trạng', 'Tổng chi phí thuê phù hợp'],
    check: ['Lập dự toán và khoản dự phòng', 'Khảo sát mặt bằng, điều kiện thuê', 'Duyệt thiết kế, báo giá và tiến độ', 'Chốt menu, thiết bị và nội thất', 'Tuyển dụng, đào tạo phục vụ', 'Vận hành thử và điều chỉnh']
  },
  large: {
    name: 'Quán ngồi lại quy mô lớn', icon: 'store', range: 'Từ 500 triệu',
    note: 'Đầu tư lớn hơn, cần lộ trình rộng: menu, nhân sự, vận hành.',
    // Số ước tính ban đầu — chờ Phòng Đào tạo xác nhận
    costNotes: ['', 'Thiết kế, sửa mặt bằng, điện nước, quầy bar', 'Bàn ghế, đèn, cây xanh, trang trí', 'Máy pha cà phê, máy xay, máy ép, tủ mát, tủ đông, máy tính tiền (POS)', 'Máy lạnh, đèn, âm thanh, wifi, camera', 'Nguyên liệu những ngày đầu, giấy phép kinh doanh, vệ sinh an toàn thực phẩm, khai trương'],
    fixedNotes: ['Tiền thuê mặt bằng mỗi tháng', 'Lương nhân viên, tính cả công của bạn', 'Điện, nước, internet, chi phí lặt vặt'],
    costs: [['Đặt cọc mặt bằng', 90], ['Thiết kế, thi công & sửa chữa', 120], ['Bàn ghế, nội thất & trang trí', 65], ['Thiết bị pha chế & bảo quản', 70], ['Điều hòa, ánh sáng & tiện ích', 40], ['Nguyên liệu, pháp lý & khai trương', 20]],
    fixed: [['Tiền thuê', 30], ['Nhân sự, gồm công của chủ', 45], ['Điện, nước & chi phí khác', 15]],
    price: 45000, ingredient: 13000, pack: 1000, fee: 0, promo: 1000, daily: 150,
    menu: [['Cafe sữa', 39000, 9000, 1000], ['Trà trái cây', 49000, 15000, 1000], ['Trà sữa', 45000, 12000, 1000], ['Nước ép cam', 49000, 18000, 1000]],
    criteria: ['Khách mục tiêu & dễ tiếp cận', 'Chỗ đỗ xe và lối vào', 'Diện tích, số chỗ ngồi', 'Điện nước, tiện ích, hiện trạng', 'Tổng chi phí thuê phù hợp'],
    check: ['Lập dự toán và khoản dự phòng', 'Khảo sát mặt bằng, điều kiện thuê', 'Duyệt thiết kế, báo giá và tiến độ', 'Chốt menu, thiết bị và nội thất', 'Tuyển dụng, phân ca, đào tạo đội ngũ', 'Vận hành thử và điều chỉnh']
  }
};

// Mẫu phân bổ tham khảo (không phải số liệu thị trường). Chi phí ban đầu + dự phòng = 100%.
const allocationSuggestions = {
  cart: { costs: [25, 15, 5, 7, 8, 5], reserve: 35 },
  takeaway: { costs: [10, 20, 22, 5, 5, 3], reserve: 35 },
  seated: { costs: [8, 23, 12, 14, 8, 5], reserve: 30 },
  large: { costs: [10, 20, 11, 12, 7, 4], reserve: 36 } // ước tính — chờ xác nhận
};

/* ---------- Khóa học điều hướng theo mô hình (theo bảng Anh Sang chốt) ---------- */
const COURSES = {
  xeTra: { tag: '50–70 triệu', title: 'Khóa học pha chế kinh doanh Xe Trà', subtitle: 'Cho mô hình vốn nhỏ, tinh gọn, chỉ bán mang đi.', topics: ['Mô hình vốn nhỏ, tinh gọn', 'Chỉ bán mang đi', 'Dễ tiếp cận cho người mới'] },
  takeAway: { tag: '100–200 triệu', title: 'Khóa học pha chế kinh doanh Coffee & Tea – Take Away', subtitle: 'Cho quán mang đi bán cả trà và cà phê.', topics: ['Trà trái cây, trà sữa và cà phê', 'Mô hình bán mang đi', 'Bán được nhiều món hơn xe trà'] },
  ngoiLai: { tag: 'Từ 300 triệu', title: 'Khóa học pha chế kinh doanh Coffee & Tea – Ngồi Lại', subtitle: 'Cho quán có không gian ngồi lại, menu đa dạng.', topics: ['Không gian ngồi lại', 'Menu đa dạng hơn', 'Kết hợp thêm nước ép'] },
  tongHop: { tag: 'Từ 500 triệu', title: 'Khóa học pha chế kinh doanh (Tổng hợp)', subtitle: 'Lộ trình rộng cho mô hình đầu tư lớn.', topics: ['Lộ trình rộng', 'Cho mô hình đầu tư lớn hơn'] }
};
const COURSE_BY_MODEL = { cart: 'xeTra', takeaway: 'takeAway', seated: 'ngoiLai', large: 'tongHop' };
