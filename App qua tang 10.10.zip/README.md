# Mở Quán — Bộ công cụ mở quán đầu tiên (SaLy Academy)

Website tĩnh (HTML, CSS, JavaScript thuần), không cần cài thư viện hay chạy lệnh build. Giao diện theo nhận diện SaLy Academy (lypham.vn) và được thiết kế ưu tiên cho điện thoại.

Người dùng chọn một trong hai lối vào:

- **Tôi sắp mở quán:** nhập số vốn, app chọn 1 trong 4 mô hình (Take away bán mang đi 50–70 triệu, Take away Trà & Cafe 100–200 triệu, Quán ngồi lại từ 300 triệu, Quán ngồi lại quy mô lớn từ 500 triệu), rồi đi qua 5 bước: Vốn đầu tư → Hòa vốn → Giá vốn menu → Mặt bằng → Lộ trình.
- **Tôi đã có quán:** chọn mô hình, đi qua 2 bước: Lãi lỗ → Giá vốn menu.

Khi hoàn tất, người dùng có thể tải kế hoạch về máy, xem khóa học phù hợp và đăng ký tư vấn. Kế hoạch được gửi kèm form đăng ký.

## Cấu trúc repo

```
.
├── index.html                    # Trang chính
├── style.css                     # Giao diện
├── data.js                       # SỐ LIỆU & KHÓA HỌC — Phòng Đào tạo sửa tại đây
├── app.js                        # Logic tính toán, các bước, form
├── assets/logo-saly-academy.png  # Logo
├── .nojekyll
├── .gitignore
└── README.md
```

## Sửa số liệu và khóa học

Mọi số liệu mẫu (chi phí ban đầu, chi phí cố định, giá bán, nguyên liệu, bao bì, tỷ lệ phân bổ vốn, menu mẫu) và danh sách khóa học nằm trong `data.js`. Sửa số trong file này rồi tải lên lại, không cần đụng tới `app.js`.

**Trạng thái số liệu:** các số về chi phí và giá vốn chưa có trong kho tri thức Học viện; Anh Sang tạm xác nhận dùng ngày 01/10/2026. Khi Phòng Đào tạo chốt số chuẩn, sửa trong `data.js` (đối chiếu file `bang-so-lieu-can-xac-nhan.xlsx`, không nằm trong repo).

**Số mẫu co giãn theo vốn:** với người sắp mở quán, app tự nhân tỷ lệ chi phí ban đầu, chi phí tháng và số ly/ngày theo vốn khách nhập, để chi phí ban đầu + 3 tháng vốn vận hành ≈ 90% vốn, 10% còn lại là quỹ rủi ro. Người đã có quán dùng số mẫu gốc. Muốn tắt: trong `app.js`, cho hàm `scaleFor` luôn trả về `1`.

## Bật gửi form thật

Trong `app.js`, dòng đầu file:

```js
const SUBMIT_URL = '';
```

- Để trống: form chỉ hiển thị bản xem trước, không gửi dữ liệu.
- Dán địa chỉ nhận dữ liệu (ví dụ webhook n8n): form gửi `POST` JSON và hiện thông báo "Đã gửi đăng ký".

Cấu trúc dữ liệu gửi đi (`schema_version: 2`):

| Trường | Nội dung |
|---|---|
| `contact` | Họ tên, điện thoại, email, câu hỏi và trả lời về thời gian, lời nhắn |
| `interest` | Nhu cầu: tư vấn kế hoạch hoặc tên khóa học |
| `course_model` | Mã khóa học được chọn (`xeTra`, `takeAway`, `ngoiLai`, `tongHop`) hoặc `null` |
| `plan.visitor_type` | `chuan_bi_mo` (sắp mở) hoặc `dang_kinh_doanh` (đã có quán) |
| `plan.inputs`, `plan.results`, `plan.text` | Toàn bộ số liệu người dùng nhập, kết quả tính và bản kế hoạch dạng chữ |
| `consent`, `source`, `created_at` | Đồng ý liên hệ, trang gửi, thời điểm gửi |

## Tự lưu

Kế hoạch đang làm được lưu trên trình duyệt của người dùng (localStorage). Khi quay lại, trang đầu hiện nút **Làm tiếp**. Dữ liệu này không gửi đi đâu.

## Đưa lên GitHub Pages hoặc Vercel

**GitHub Pages:**
1. Tạo repository **Public**. Bấm **Add file → Upload files**, kéo **toàn bộ nội dung bên trong thư mục** (kể cả thư mục `assets`) vào, bấm **Commit changes**.
2. Vào **Settings → Pages** → **Deploy from a branch** → nhánh `main`, thư mục `/(root)` → **Save**.
3. Đợi 1–2 phút, địa chỉ web hiện tại mục Pages.

**Vercel:** chọn repo, Framework Preset để **Other**, không cần lệnh build, thư mục xuất bản để trống (thư mục gốc).

File `.nojekyll` và `.gitignore` là file ẩn. Trên Mac bấm `Cmd + Shift + .` để hiện trước khi kéo.
